-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 
-- Port     : 
-- Database : 
-- 
-- Part : #1
-- Date : 2018-07-16 14:35:05
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `fa_admin`
-- -----------------------------
DROP TABLE IF EXISTS `fa_admin`;
CREATE TABLE `fa_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `username` varchar(20) NOT NULL DEFAULT '' COMMENT '用户名',
  `nickname` varchar(50) NOT NULL DEFAULT '' COMMENT '昵称',
  `password` varchar(32) NOT NULL DEFAULT '' COMMENT '密码',
  `salt` varchar(30) NOT NULL DEFAULT '' COMMENT '密码盐',
  `avatar` varchar(100) NOT NULL DEFAULT '' COMMENT '头像',
  `email` varchar(100) NOT NULL DEFAULT '' COMMENT '电子邮箱',
  `loginfailure` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '失败次数',
  `logintime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录时间',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `token` varchar(59) NOT NULL DEFAULT '' COMMENT 'Session标识',
  `status` varchar(30) NOT NULL DEFAULT 'normal' COMMENT '状态',
  `ip` varchar(30) DEFAULT NULL COMMENT '创建ip地址',
  `ip_address` varchar(255) DEFAULT NULL COMMENT '创建地点',
  `login_ip` char(15) DEFAULT NULL COMMENT '最后一次登录ip',
  `login_ip_address` varchar(255) DEFAULT NULL COMMENT '最后一次登录地点',
  `sex` tinyint(1) DEFAULT NULL COMMENT '性别 1：男  2：女  3：保密',
  `mobile` int(11) DEFAULT NULL COMMENT '手机号',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='管理员表';

-- -----------------------------
-- Records of `fa_admin`
-- -----------------------------
INSERT INTO `fa_admin` VALUES ('43', 'admin', 'kek2f', 'e10adc3949ba59abbe56e057f20f883e', 'ysCSl4', '/assets/img/avatar.png', '2383850708@qq.com', '0', '1528380240', '1531722679', '4b50q65ifsjhkhb58ps2v9f7o7', '1', '127.0.0.1', 'XX内网IP', '192.168.8.218', 'XX内网IP', '1', '2147483647', '0');
INSERT INTO `fa_admin` VALUES ('45', 'admin1', 'b2', 'e10adc3949ba59abbe56e057f20f883e', 'AUxsNL', '/assets/img/avatar.png', '23838@qq.com', '0', '1528377713', '1530777642', '', '1', '127.0.0.1', 'XX内网IP', '127.0.0.1', 'XX内网IP', '0', '0', '1528361228');
INSERT INTO `fa_admin` VALUES ('48', '测试', '测试了', 'e10adc3949ba59abbe56e057f20f883e', '1nXPOI', '/assets/img/avatar.png', '', '0', '0', '1530608207', '', '1', '127.0.0.1', 'XX内网IP', '', '', '0', '0', '1530608207');
INSERT INTO `fa_admin` VALUES ('49', 'ceshi1', 'a', 'e10adc3949ba59abbe56e057f20f883e', 'Vfp4IW', '/assets/img/avatar.png', '', '0', '0', '1531707279', 'qln99190dcs0msjd6vkmu7rc31', '1', '127.0.0.1', 'XX内网IP', '127.0.0.1', 'XX内网IP', '0', '0', '1530777365');
INSERT INTO `fa_admin` VALUES ('50', 'ceshi4', '1', 'e10adc3949ba59abbe56e057f20f883e', 'Lw8GRX', '/assets/img/avatar.png', '', '0', '0', '1530777537', '', '1', '127.0.0.1', 'XX内网IP', '', '', '0', '0', '1530777537');
