-- -----------------------------
-- Think MySQL Data Transfer 
-- 
-- Host     : 
-- Port     : 
-- Database : 
-- 
-- Part : #1
-- Date : 2018-07-11 16:30:04
-- -----------------------------

SET FOREIGN_KEY_CHECKS = 0;


-- -----------------------------
-- Table structure for `fa_admin`
-- -----------------------------
DROP TABLE IF EXISTS `fa_admin`;
CREATE TABLE `fa_admin` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT 'ID',
  `username` varchar(20) NOT NULL DEFAULT '' COMMENT '用户名',
  `nickname` varchar(50) NOT NULL DEFAULT '' COMMENT '昵称',
  `password` varchar(32) NOT NULL DEFAULT '' COMMENT '密码',
  `salt` varchar(30) NOT NULL DEFAULT '' COMMENT '密码盐',
  `avatar` varchar(100) NOT NULL DEFAULT '' COMMENT '头像',
  `email` varchar(100) NOT NULL DEFAULT '' COMMENT '电子邮箱',
  `loginfailure` tinyint(1) unsigned NOT NULL DEFAULT '0' COMMENT '失败次数',
  `logintime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '登录时间',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `token` varchar(59) NOT NULL DEFAULT '' COMMENT 'Session标识',
  `status` varchar(30) NOT NULL DEFAULT 'normal' COMMENT '状态',
  `ip` varchar(30) DEFAULT NULL COMMENT '创建ip地址',
  `ip_address` varchar(255) DEFAULT NULL COMMENT '创建地点',
  `login_ip` char(15) DEFAULT NULL COMMENT '最后一次登录ip',
  `login_ip_address` varchar(255) DEFAULT NULL COMMENT '最后一次登录地点',
  `sex` tinyint(1) DEFAULT NULL COMMENT '性别 1：男  2：女  3：保密',
  `mobile` int(11) DEFAULT NULL COMMENT '手机号',
  `createtime` int(11) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=51 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='管理员表';

-- -----------------------------
-- Records of `fa_admin`
-- -----------------------------
INSERT INTO `fa_admin` VALUES ('43', 'admin', 'kek2f', 'e10adc3949ba59abbe56e057f20f883e', 'ysCSl4', '/assets/img/avatar.png', '2383850708@qq.com', '0', '1528380240', '1531287531', 'umohqb0q2kfka2qiu38bq55id5', '1', '127.0.0.1', 'XX内网IP', '127.0.0.1', 'XX内网IP', '1', '2147483647', '0');
INSERT INTO `fa_admin` VALUES ('45', 'admin1', 'b2', 'e10adc3949ba59abbe56e057f20f883e', 'AUxsNL', '/assets/img/avatar.png', '23838@qq.com', '0', '1528377713', '1530777642', '', '1', '127.0.0.1', 'XX内网IP', '127.0.0.1', 'XX内网IP', '0', '0', '1528361228');
INSERT INTO `fa_admin` VALUES ('48', '测试', '测试了', 'e10adc3949ba59abbe56e057f20f883e', '1nXPOI', '/assets/img/avatar.png', '', '0', '0', '1530608207', '', '1', '127.0.0.1', 'XX内网IP', '', '', '0', '0', '1530608207');
INSERT INTO `fa_admin` VALUES ('49', 'ceshi3', 'a', 'e10adc3949ba59abbe56e057f20f883e', 'Vfp4IW', '/assets/img/avatar.png', '', '0', '0', '1530777365', '', '1', '127.0.0.1', 'XX内网IP', '', '', '0', '0', '1530777365');
INSERT INTO `fa_admin` VALUES ('50', 'ceshi4', '1', 'e10adc3949ba59abbe56e057f20f883e', 'Lw8GRX', '/assets/img/avatar.png', '', '0', '0', '1530777537', '', '1', '127.0.0.1', 'XX内网IP', '', '', '0', '0', '1530777537');

-- -----------------------------
-- Table structure for `fa_article`
-- -----------------------------
DROP TABLE IF EXISTS `fa_article`;
CREATE TABLE `fa_article` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '主键',
  `title` varchar(40) CHARACTER SET utf8 NOT NULL COMMENT '标题',
  `author` varchar(20) CHARACTER SET utf8 DEFAULT NULL COMMENT '作者',
  `status` tinyint(1) NOT NULL COMMENT '状态  1：发布  0：草稿',
  `categoryid` int(11) DEFAULT NULL COMMENT '类别id',
  `keywords` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '关键字,多个已逗号分开',
  `reading` int(11) DEFAULT '0' COMMENT '阅读次数',
  `content` text CHARACTER SET utf8 NOT NULL COMMENT '内容',
  `synopsis` text CHARACTER SET utf8 COMMENT '简介',
  `pic` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '图片',
  `tag` tinyint(2) DEFAULT NULL COMMENT '标签  0：转载  1：原创',
  `is_good` tinyint(1) DEFAULT NULL COMMENT '是否推荐 0：不推荐 1：推荐',
  `createtime` int(11) DEFAULT NULL COMMENT '创建时间',
  `updatetime` int(11) DEFAULT NULL COMMENT '修改日期',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=gbk COMMENT='文章表';

-- -----------------------------
-- Records of `fa_article`
-- -----------------------------
INSERT INTO `fa_article` VALUES ('7', '测试2', '小温', '1', '14', '123', '0', '<p>4231</p>', '123', '20180629\dfb5f37d4421e40b55354713770d7184.jpg', '0', '2', '1530259130', '1530259130');
INSERT INTO `fa_article` VALUES ('8', '12', '12', '1', '17', '', '0', '', '', '20180629\dfc2f68e050b0d48af58c98ae31003b0.jpg', '0', '2', '1530259204', '1530259204');
INSERT INTO `fa_article` VALUES ('6', '测试1', '小文', '1', '6', '1', '0', '', '', '20180629\0ff995943b8d6d0ad47fb767a4ee2570.jpg', '0', '2', '1530258995', '1530258995');

-- -----------------------------
-- Table structure for `fa_auth_group`
-- -----------------------------
DROP TABLE IF EXISTS `fa_auth_group`;
CREATE TABLE `fa_auth_group` (
  `id` mediumint(8) unsigned NOT NULL AUTO_INCREMENT,
  `title` char(100) NOT NULL DEFAULT '' COMMENT '标题',
  `status` tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态',
  `rules` char(80) NOT NULL DEFAULT '' COMMENT '权限 逗号分隔',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=136 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='角色表';

-- -----------------------------
-- Records of `fa_auth_group`
-- -----------------------------
INSERT INTO `fa_auth_group` VALUES ('128', '超级管理员', '1', '134,110,147,148,149,150,151,140,142,145,146,141,143,144,130,131,132,133,135,136,');
INSERT INTO `fa_auth_group` VALUES ('129', '产品管理员', '1', '134,110,130,133');
INSERT INTO `fa_auth_group` VALUES ('131', '管理员管理', '1', '130,131,133,135');
INSERT INTO `fa_auth_group` VALUES ('132', '文章管理', '1', '134,110');
INSERT INTO `fa_auth_group` VALUES ('133', 'ceshi1', '1', '130,131');
INSERT INTO `fa_auth_group` VALUES ('134', 'ceshi2', '1', '130,132');
INSERT INTO `fa_auth_group` VALUES ('135', 'ceshi3', '1', '134');

-- -----------------------------
-- Table structure for `fa_auth_group_access`
-- -----------------------------
DROP TABLE IF EXISTS `fa_auth_group_access`;
CREATE TABLE `fa_auth_group_access` (
  `uid` int(10) unsigned NOT NULL COMMENT '会员ID',
  `group_id` int(10) unsigned NOT NULL COMMENT '级别ID',
  UNIQUE KEY `uid_group_id` (`uid`,`group_id`),
  KEY `uid` (`uid`),
  KEY `group_id` (`group_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='权限分组表';

-- -----------------------------
-- Records of `fa_auth_group_access`
-- -----------------------------
INSERT INTO `fa_auth_group_access` VALUES ('43', '128');
INSERT INTO `fa_auth_group_access` VALUES ('44', '129');
INSERT INTO `fa_auth_group_access` VALUES ('45', '128');
INSERT INTO `fa_auth_group_access` VALUES ('46', '129');
INSERT INTO `fa_auth_group_access` VALUES ('48', '131');
INSERT INTO `fa_auth_group_access` VALUES ('49', '129');
INSERT INTO `fa_auth_group_access` VALUES ('50', '131');

-- -----------------------------
-- Table structure for `fa_auth_rule`
-- -----------------------------
DROP TABLE IF EXISTS `fa_auth_rule`;
CREATE TABLE `fa_auth_rule` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `type` enum('menu','file') NOT NULL DEFAULT 'file' COMMENT 'menu为菜单,file为权限节点',
  `pid` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '父ID',
  `name` varchar(100) NOT NULL DEFAULT '' COMMENT '规则名称',
  `title` varchar(50) NOT NULL DEFAULT '' COMMENT '规则名称',
  `icon` varchar(50) NOT NULL DEFAULT '' COMMENT '图标',
  `condition` varchar(255) NOT NULL DEFAULT '' COMMENT '条件',
  `remark` varchar(255) NOT NULL DEFAULT '' COMMENT '备注',
  `ischeck` tinyint(1) unsigned NOT NULL DEFAULT '1' COMMENT '是否验证 1：验证  0不验证',
  `createtime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '创建时间',
  `updatetime` int(10) unsigned NOT NULL DEFAULT '0' COMMENT '更新时间',
  `weigh` int(10) NOT NULL DEFAULT '0' COMMENT '权重',
  `status` varchar(30) NOT NULL DEFAULT '' COMMENT '状态',
  `level` tinyint(4) NOT NULL DEFAULT '0' COMMENT '级别',
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`) USING BTREE,
  KEY `pid` (`pid`),
  KEY `weigh` (`weigh`)
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=utf8 ROW_FORMAT=COMPACT COMMENT='节点表';

-- -----------------------------
-- Records of `fa_auth_rule`
-- -----------------------------
INSERT INTO `fa_auth_rule` VALUES ('110', 'menu', '0', 'dashboard/index', '控制台', 'layui-icon layui-icon-console', '', '', '1', '0', '1530758944', '0', '1', '0');
INSERT INTO `fa_auth_rule` VALUES ('130', 'menu', '0', 'auth', '权限管理', 'layui-icon layui-icon-user', '', '', '1', '1528441900', '1530758966', '0', '1', '0');
INSERT INTO `fa_auth_rule` VALUES ('131', 'menu', '130', 'auth.admin/index', '管理员管理', 'fa fa-bars', '', '', '1', '1528441973', '1528446716', '0', '1', '1');
INSERT INTO `fa_auth_rule` VALUES ('132', 'menu', '130', 'auth.group/index', '角色管理', 'fa fa-bars', '', '', '1', '1528442017', '1528446675', '0', '1', '1');
INSERT INTO `fa_auth_rule` VALUES ('133', 'menu', '130', 'auth.rule/index', '菜单规则', 'fa fa-bars', '', '', '1', '1528442066', '1530714286', '0', '1', '1');
INSERT INTO `fa_auth_rule` VALUES ('134', 'menu', '0', 'index/index', '首页', 'fa fa-bars', '', '', '1', '1528446536', '1530683361', '100', '1', '0');
INSERT INTO `fa_auth_rule` VALUES ('135', 'file', '133', 'auth.rule/ajax_load_data', '列表', 'fa fa-bars', '', '', '1', '1528773008', '1528773817', '0', '1', '2');
INSERT INTO `fa_auth_rule` VALUES ('136', 'file', '133', 'auth.rule/add', '添加', 'fa fa-bars', '', '', '1', '1528960414', '1530694077', '0', '1', '2');
INSERT INTO `fa_auth_rule` VALUES ('137', 'menu', '0', 'article', '文章管理', 'layui-icon layui-icon-list', '', '', '1', '1530693243', '1530758992', '0', '1', '0');
INSERT INTO `fa_auth_rule` VALUES ('138', 'menu', '137', 'article.article/index', '文章列表', 'fa fa-bars', '', '', '1', '1530693328', '1530693328', '0', '1', '1');
INSERT INTO `fa_auth_rule` VALUES ('139', 'menu', '137', 'article.category/index', '分类管理', 'fa fa-bars', '', '', '1', '1530693375', '1530693375', '0', '1', '1');
INSERT INTO `fa_auth_rule` VALUES ('140', 'menu', '0', 'set', '设置', 'layui-icon layui-icon-set', '', '', '1', '1530693415', '1530759013', '0', '1', '0');
INSERT INTO `fa_auth_rule` VALUES ('141', 'menu', '140', 'system', '系统设置', 'fa fa-bars', '', '', '1', '1530693460', '1530693460', '0', '1', '1');
INSERT INTO `fa_auth_rule` VALUES ('142', 'menu', '140', 'myset', '我的设置', 'fa fa-bars', '', '', '1', '1530693504', '1530693504', '0', '1', '1');
INSERT INTO `fa_auth_rule` VALUES ('143', 'menu', '141', 'set.system/index', '网站设置', 'fa fa-bars', '', '', '1', '1530693592', '1530693592', '0', '1', '2');
INSERT INTO `fa_auth_rule` VALUES ('144', 'menu', '141', 'set.email/index', '邮件服务', 'fa fa-bars', '', '', '1', '1530693626', '1530693626', '0', '1', '2');
INSERT INTO `fa_auth_rule` VALUES ('145', 'menu', '142', 'set.basic_information/index', '基本资料', 'fa fa-bars', '', '', '1', '1530693653', '1530693653', '0', '1', '2');
INSERT INTO `fa_auth_rule` VALUES ('146', 'menu', '142', 'set.modify_passwork/index', '修改密码', 'fa fa-bars', '', '', '1', '1530693672', '1530693672', '0', '1', '2');
INSERT INTO `fa_auth_rule` VALUES ('147', 'menu', '0', 'database', '数据库管理', 'layui-icon layui-icon-template-1', '', '', '1', '1531287650', '1531287650', '0', '1', '0');
INSERT INTO `fa_auth_rule` VALUES ('148', 'menu', '147', 'database/backups', '数据库备份', 'fa fa-bars', '', '', '1', '1531287750', '1531287750', '0', '1', '1');
INSERT INTO `fa_auth_rule` VALUES ('149', 'menu', '147', 'database/reduction', '数据库还原', 'fa fa-bars', '', '', '1', '1531287791', '1531287791', '0', '1', '1');
INSERT INTO `fa_auth_rule` VALUES ('150', 'menu', '0', 'payment', '支付管理', 'layui-icon layui-icon-rmb', '', '', '1', '1531287950', '1531287979', '0', '1', '0');
INSERT INTO `fa_auth_rule` VALUES ('151', 'menu', '150', 'payment/alipay', '支付宝', 'fa fa-bars', '', '', '1', '1531288040', '1531288040', '0', '1', '1');

-- -----------------------------
-- Table structure for `fa_category`
-- -----------------------------
DROP TABLE IF EXISTS `fa_category`;
CREATE TABLE `fa_category` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT COMMENT '自增id',
  `title` varchar(100) CHARACTER SET utf8 DEFAULT '' COMMENT '标题',
  `pid` tinyint(2) DEFAULT NULL COMMENT '父id',
  `scort` tinyint(2) DEFAULT '0' COMMENT '排序',
  `createtime` int(11) DEFAULT NULL COMMENT '创建时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=18 DEFAULT CHARSET=gbk COMMENT='分类表';

-- -----------------------------
-- Records of `fa_category`
-- -----------------------------
INSERT INTO `fa_category` VALUES ('6', '首页', '0', '0', '1529935295');
INSERT INTO `fa_category` VALUES ('7', '源码', '0', '0', '1529935308');
INSERT INTO `fa_category` VALUES ('8', '模板', '0', '0', '1529935318');
INSERT INTO `fa_category` VALUES ('9', '微信', '0', '0', '1529935342');
INSERT INTO `fa_category` VALUES ('10', '后台模板', '8', '0', '1529935381');
INSERT INTO `fa_category` VALUES ('11', 'HTML5模板', '8', '0', '1529935413');
INSERT INTO `fa_category` VALUES ('12', 'DeDe模板', '8', '0', '1529935427');
INSERT INTO `fa_category` VALUES ('13', 'WP模板', '8', '0', '1529935442');
INSERT INTO `fa_category` VALUES ('14', 'PHP源码', '7', '0', '1529935508');
INSERT INTO `fa_category` VALUES ('15', 'Java源码', '7', '0', '1529935530');
INSERT INTO `fa_category` VALUES ('16', 'ThinkPHP源码', '7', '0', '1529935545');
INSERT INTO `fa_category` VALUES ('17', '测试', '14', '0', '1529998038');

-- -----------------------------
-- Table structure for `fa_email_set`
-- -----------------------------
DROP TABLE IF EXISTS `fa_email_set`;
CREATE TABLE `fa_email_set` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `smtp_server` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT 'SMTP服务器',
  `smtp_port` int(11) DEFAULT NULL COMMENT 'SMTP端口号',
  `send_nickname` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '昵称',
  `send_email` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '邮件账号',
  `send_password` varchar(50) CHARACTER SET utf8 DEFAULT NULL COMMENT '邮箱密码',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=gbk;

-- -----------------------------
-- Records of `fa_email_set`
-- -----------------------------
INSERT INTO `fa_email_set` VALUES ('1', 'smtp.aliyun.com', '465', '贤心', 'xianxin@layui-inc.com', '123456');

-- -----------------------------
-- Table structure for `fa_order`
-- -----------------------------
DROP TABLE IF EXISTS `fa_order`;
CREATE TABLE `fa_order` (
  `id` int(11) unsigned zerofill NOT NULL AUTO_INCREMENT,
  `body` varchar(50) DEFAULT NULL,
  `total_fee` int(11) DEFAULT NULL,
  `transaction_id` varchar(50) DEFAULT NULL,
  `out_trade_no` varchar(50) DEFAULT NULL,
  `product_id` varchar(30) DEFAULT NULL,
  `status` tinyint(4) DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

-- -----------------------------
-- Records of `fa_order`
-- -----------------------------
INSERT INTO `fa_order` VALUES ('1', '支付测试', '1', '', '409329171530847418', '1530847418', '0');

-- -----------------------------
-- Table structure for `fa_pay`
-- -----------------------------
DROP TABLE IF EXISTS `fa_pay`;
CREATE TABLE `fa_pay` (
  `out_trade_no` varchar(100) NOT NULL,
  `money` decimal(10,2) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT '0',
  `callback` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `param` text NOT NULL,
  `create_time` int(11) NOT NULL,
  `update_time` int(11) NOT NULL,
  PRIMARY KEY (`out_trade_no`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


-- -----------------------------
-- Table structure for `fa_prompt`
-- -----------------------------
DROP TABLE IF EXISTS `fa_prompt`;
CREATE TABLE `fa_prompt` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `success_icon` int(1) NOT NULL DEFAULT '1' COMMENT '成功提示图标',
  `error_icon` int(1) NOT NULL DEFAULT '2' COMMENT '错误提示图标',
  `skin` varchar(255) CHARACTER SET utf8 DEFAULT 'layui-layer-lan' COMMENT '皮肤',
  `anim` int(255) DEFAULT '1' COMMENT '动画效果',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=gbk COMMENT='提示图标';

-- -----------------------------
-- Records of `fa_prompt`
-- -----------------------------
INSERT INTO `fa_prompt` VALUES ('1', '1', '2', 'layui-layer-lan', '1');

-- -----------------------------
-- Table structure for `fa_system`
-- -----------------------------
DROP TABLE IF EXISTS `fa_system`;
CREATE TABLE `fa_system` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'id',
  `title` char(20) NOT NULL,
  `domain_name` varchar(100) CHARACTER SET utf8 NOT NULL COMMENT '域名',
  `cache_time` tinyint(3) NOT NULL COMMENT '缓存时间 本地开发一般推荐设置为 0，线上环境建议设置为 10',
  `upload_size` int(11) NOT NULL COMMENT '文件上传大小',
  `upload_type` varchar(100) CHARACTER SET utf8 NOT NULL COMMENT '文件上传类型',
  `keywords` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '关键字',
  `description` text CHARACTER SET utf8 COMMENT '网站描述',
  `icp` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT 'icp备案号',
  `name` varchar(255) CHARACTER SET utf8 DEFAULT NULL COMMENT '首页标题',
  `logo` varchar(100) CHARACTER SET utf8 DEFAULT NULL COMMENT '网站logo',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=gbk;

-- -----------------------------
-- Records of `fa_system`
-- -----------------------------
INSERT INTO `fa_system` VALUES ('1', 'layuiAdmin2', 'http://www.layui.com', '1', '1', 'png|gif|jpg|jpeg|zip|rar', '1', 'layuiAdmin 是 layui 官方出品的通用型后台模板解决方案，提供了单页版和 iframe 版两种开发模式。layuiAdmin 是目前非常流行的后台模板框架，广泛用于各类管理平台。', '© 2018 layui.com MIT license', 'layuiAdmin 通用后台管理模板系统', '/faicon.ico');
